apt update && upgrade
pkg install ruby -y
pkg install figlet -y
pkg install lolcat -y
gem install lolcat -y
bash text