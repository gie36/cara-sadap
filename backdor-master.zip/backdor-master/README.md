# backdor

Tools sadap handphone

Penginstalan

$ apt update && upgrade

$ pkg install git

$ git clone https://github.com/sixtysix-Team/backdor

$ cd backdor

$ sh backdor.sh

Gunakan serveo.net untuk port
